/* Copyright 2020 kb-elmo<mail@elmo.space>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include QMK_KEYBOARD_H

enum {
    SUPER_F4,
    GUI_FILE,
    SFT_CAPS,
    ABOVE_SUS,
    MUTE_PAUSE,
    COPY_CUT,
    PRINT_DEL,
    ALT_TAP,
    LEFT_RIGHT
};

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    /* Base */
    [0] = LAYOUT(
    C(KC_S),C(KC_X),C(KC_C),C(KC_V), KC_MPRV,KC_VOLD,KC_VOLU,KC_MNXT, G(C(KC_LEFT)),G(C(KC_F4)),G(C(KC_D)),G(C(KC_RGHT)), DM_REC1,DM_PLY1,DM_REC2,DM_PLY2, TD(MUTE_PAUSE),TD(ABOVE_SUS), \
        KC_ESC,  KC_1,    KC_2,    KC_3,    KC_4,    KC_5,    KC_6,  KC_EQL,  KC_7,    KC_8,    KC_9,    KC_0,    KC_MINS,   KC_BSPC, TD(PRINT_DEL),  KC_NLCK, KC_PSLS, KC_PAST, KC_PMNS, \
        KC_TAB,  KC_Q,    KC_W,    KC_F,    KC_P,    KC_G,    KC_LBRC,    KC_J,    KC_L,    KC_U,    KC_Y,    KC_SCLN, KC_QUOT, KC_GRV,  KC_BSLS,     KC_P7,   KC_P8,   KC_P9,   KC_PPLS, \
        KC_LCTL, KC_A,    KC_R,    KC_S,    KC_T,    KC_D,    KC_RBRC,    KC_H,    KC_N,    KC_E,    KC_I, KC_O,          KC_ENT,  KC_PGUP,     KC_P4,KC_P5,KC_P6,   KC_COMM, \
        OSL(1),   KC_LSFT, KC_Z,    KC_X,    KC_C,    KC_V,    KC_B,  KC_SLSH,  KC_K,    KC_M,    KC_COMM, KC_DOT,   MT(MOD_RSFT,KC_CAPS),KC_UP,KC_PGDN,  KC_P1,KC_P2,KC_P3,            \
        TD(GUI_FILE),                                          KC_SPC,                            TD(ALT_TAP), KC_LEFT, KC_DOWN, KC_RGHT,     KC_P0, KC_PDOT, KC_ENT  \
    ),
    [1] = LAYOUT(
        RESET, KC_TRNS, KC_TRNS, KC_TRNS,   KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,   KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,      KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,     KC_TRNS, KC_TRNS, \
        KC_TRNS, KC_F1, KC_F2, KC_F3, TD(SUPER_F4), KC_F5, KC_F6, KC_F12, KC_F7, KC_F8, KC_F9, KC_F10, KC_F11, KC_TRNS, KC_TRNS,     KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, \
        KC_TRNS, KC_TRNS, C(G(KC_D)), KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, G(KC_TAB), KC_TRNS,  KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, \
        KC_TRNS, C(G(KC_LEFT)), C(G(KC_F4)), C(G(KC_RGHT)), KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, \
        KC_TRNS, KC_TRNS, KC_TRNS, C(KC_X), C(KC_C), C(KC_V), KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,     KC_TRNS, KC_TRNS, KC_TRNS,          \
        KC_TRNS,                                              KC_TRNS,                                     KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,     KC_TRNS,          KC_TRNS, KC_TRNS  \
    )
};


// SUPER_F4 TAP DANCE
void dance_sf4_finished(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        register_code16(KC_F4);
    } else {
        register_code(KC_LALT);
        register_code(KC_F4);
    }
}

void dance_sf4_reset(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        unregister_code16(KC_F4);
    } else {
        unregister_code(KC_LALT);
        unregister_code(KC_F4);
    }
}

// GUI_FILE TAP DANCE
void dance_gfile_finished(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        register_code16(KC_LGUI);
    } else {
        register_code(KC_LGUI);
        register_code(KC_E);
    }
}

void dance_gfile_reset(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        unregister_code16(KC_LGUI);
    } else {
        unregister_code(KC_LGUI);
        unregister_code(KC_E);
    }
}

// SFT_CAPS TAP DANCE
void dance_scaps_finished(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        register_code16(KC_LSFT);
    } else {
        register_code(KC_CAPS);
    }
}

void dance_scaps_reset(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        unregister_code16(KC_LSFT);
    } else {
        unregister_code(KC_CAPS);
    }
     clear_mods();
}

// ABOVE_SUS TAP DANCE
void dance_asus_finished(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        register_code(KC_LGUI);
        register_code(KC_D);
    } else {
        register_code(KC_LGUI);
        register_code(KC_L);
    }
}

void dance_asus_reset(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        unregister_code16(KC_LGUI);
        unregister_code16(KC_D);
    } else {
        unregister_code16(KC_LGUI);
        unregister_code16(KC_L);
    }
}

// MUTE_PAUSE TAP DANCE
void dance_mutepause_finished(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        register_code16(KC_MPLY);
    } else {
        register_code(KC_MUTE);
    }
}

void dance_mutepause_reset(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        unregister_code16(KC_MPLY);
    } else {
        unregister_code(KC_MUTE);
    }
}

// COPY_CUT TAP DANCE
void dance_copycut_finished(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        register_code(KC_LCTL);
        register_code(KC_C);
    } else {
        register_code(KC_LCTL);
        register_code(KC_X);
    }
}

void dance_copycut_reset(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        unregister_code16(KC_LCTL);
        unregister_code16(KC_C);
    } else {
        unregister_code16(KC_LCTL);
        unregister_code16(KC_X);
    }
}

// PRINT_DEL TAP DANCE
void dance_printdel_finished(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        register_code16(KC_DEL);
    } else {
        register_code(KC_PSCR);
    }
}
void dance_printdel_reset(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        unregister_code16(KC_DEL);
    } else {
        unregister_code(KC_PSCR);
    }
}

// ALT_TAP TAP DANCE
void dance_altab_finished(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        register_code16(KC_LALT);
    } else {
        register_code(KC_LALT);
        register_code(KC_TAB);
        unregister_code(KC_TAB);
    }
}
void dance_altab_reset(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        unregister_code16(KC_LALT);
    } else {
        unregister_code16(KC_LALT);
    }
    clear_mods();
}

// LEFT_RIGHT TAP DANCE
void dance_leftright_finished(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        register_code16(KC_LWIN);
        register_code16(KC_RGHT);
    } else {
       register_code16(KC_LWIN);
        register_code16(KC_LEFT);
    }
}

void dance_leftright_reset(qk_tap_dance_state_t *state, void *user_data) {
    if (state->count == 1) {
        unregister_code16(KC_LWIN);
        unregister_code16(KC_RGHT);
    } else {
        unregister_code16(KC_LWIN);
        unregister_code16(KC_LEFT);
    }
}



// All tap dance functions go here.
qk_tap_dance_action_t tap_dance_actions[] = {
    [SUPER_F4] = ACTION_TAP_DANCE_FN_ADVANCED_TIME(NULL, dance_sf4_finished, dance_sf4_reset, 250),
    [GUI_FILE] = ACTION_TAP_DANCE_FN_ADVANCED_TIME(NULL, dance_gfile_finished, dance_gfile_reset, 250),
    [SFT_CAPS] = ACTION_TAP_DANCE_FN_ADVANCED_TIME(NULL, dance_scaps_finished, dance_scaps_reset, 15),
    [ABOVE_SUS] = ACTION_TAP_DANCE_FN_ADVANCED_TIME(NULL, dance_asus_finished, dance_asus_reset, 250),
    [MUTE_PAUSE] = ACTION_TAP_DANCE_FN_ADVANCED_TIME(NULL, dance_mutepause_finished, dance_mutepause_reset, 250),
    [COPY_CUT] = ACTION_TAP_DANCE_FN_ADVANCED_TIME(NULL, dance_copycut_finished, dance_copycut_reset, 200),
    [PRINT_DEL] = ACTION_TAP_DANCE_FN_ADVANCED_TIME(NULL, dance_printdel_finished, dance_printdel_reset, 200),
    [ALT_TAP] = ACTION_TAP_DANCE_FN_ADVANCED_TIME(NULL, dance_altab_finished, dance_altab_reset, 250),
    [LEFT_RIGHT] = ACTION_TAP_DANCE_FN_ADVANCED_TIME(NULL, dance_leftright_finished, dance_leftright_reset, 200),
    
};
